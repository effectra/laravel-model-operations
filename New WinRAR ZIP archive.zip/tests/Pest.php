<?php

// use Effectra\LaravelModelOperations\Tests\Controllers\PostController;
// use Effectra\LaravelModelOperations\Tests\Models\Post;

// require __DIR__.'/bootstrap.php';

// Post::truncate();
// Post::factory()->count(10)->create();
// $c = new PostController();
// $r=$c->deleteMany([3,5,"10"],function($model){
    
// });
// $c->undoDeleteMany([3,5,"10"]);
// dd(Post::all()->count());