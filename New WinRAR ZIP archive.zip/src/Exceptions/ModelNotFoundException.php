<?php

namespace Effectra\LaravelModelOperations\Exceptions;

/**
 * Class ModelNotFoundException
 *
 * Custom exception thrown when model not found.
 */
class ModelNotFoundException extends \Exception
{

}