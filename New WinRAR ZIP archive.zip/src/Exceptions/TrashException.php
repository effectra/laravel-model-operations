<?php

namespace Effectra\LaravelModelOperations\Exceptions;

/**
 * Class TrashException
 *
 * Custom exception thrown when trash fails.
 */
class TrashException extends \Exception
{

}